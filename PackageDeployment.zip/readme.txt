The following packages are included in this download:
   https://api.nuget.org/v3-flatcontainer/microsoft.crmsdk.xrmtooling.pluginregistrationtool/9.1.0.20/microsoft.crmsdk.xrmtooling.pluginregistrationtool.9.1.0.20.nupkg
   https://api.nuget.org/v3-flatcontainer/microsoft.crmsdk.coretools/9.1.0.68/microsoft.crmsdk.coretools.9.1.0.68.nupkg
   https://api.nuget.org/v3-flatcontainer/microsoft.crmsdk.xrmtooling.packagedeployment.wpf/9.1.0.45/microsoft.crmsdk.xrmtooling.packagedeployment.wpf.9.1.0.45.nupkg
   https://api.nuget.org/v3-flatcontainer/microsoft.crmsdk.xrmtooling.configurationmigration.wpf/9.1.0.34/microsoft.crmsdk.xrmtooling.configurationmigration.wpf.9.1.0.34.nupkg

